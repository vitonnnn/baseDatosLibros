package com.example.view;

import com.example.dao.BookDAO;
import com.example.model.Book;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

// Clase BookView, que representa la interfaz gráfica para gestionar libros.
public class BookView extends JFrame {
    // Campos de texto para introducir datos del libro
    private JTextField txtTitulo, txtAutor, txtAnio, txtId;
    // Tabla para mostrar los libros
    private JTable table;
    // Modelo de tabla para gestionar los datos que se mostrarán en la JTable
    private DefaultTableModel tableModel;
    // Objeto DAO para interactuar con la base de datos
    private BookDAO bookDAO;

    // Constructor de la clase BookView, donde se configuran los componentes de la GUI
    public BookView() {
        // Configuración básica de la ventana principal
        setTitle("Gestión de Libros"); // Título de la ventana
        setSize(600, 500); // Tamaño de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Cerrar la aplicación al cerrar la ventana
        setLayout(new BorderLayout()); // Definir el diseño del JFrame

        // Panel superior que contiene el formulario para ingresar datos
        JPanel panelSuperior = new JPanel(new GridLayout(4, 2, 10, 10)); // Distribución en rejilla
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Añadir un margen alrededor del panel

        // Etiquetas y campos de texto para ID, Título, Autor y Año de publicación
        JLabel lblId = new JLabel("ID:");
        txtId = new JTextField();
        panelSuperior.add(lblId);
        panelSuperior.add(txtId);

        JLabel lblTitulo = new JLabel("Título:");
        txtTitulo = new JTextField();
        panelSuperior.add(lblTitulo);
        panelSuperior.add(txtTitulo);

        JLabel lblAutor = new JLabel("Autor:");
        txtAutor = new JTextField();
        panelSuperior.add(lblAutor);
        panelSuperior.add(txtAutor);

        JLabel lblAnio = new JLabel("Año de Publicación:");
        txtAnio = new JTextField();
        panelSuperior.add(lblAnio);
        panelSuperior.add(txtAnio);

        // Añadir el panel superior al JFrame
        add(panelSuperior, BorderLayout.NORTH);

        // Panel que contiene los botones para realizar las operaciones CRUD
        JPanel panelBotones = new JPanel(new FlowLayout()); // Diseño de flujo (alineación)
        JButton btnAgregar = new JButton("Agregar Libro"); // Botón para agregar libro
        JButton btnListar = new JButton("Listar Libros"); // Botón para listar libros
        JButton btnActualizar = new JButton("Actualizar Libro"); // Botón para actualizar libro
        JButton btnEliminar = new JButton("Eliminar Libro"); // Botón para eliminar libro

        // Añadir los botones al panel de botones
        panelBotones.add(btnAgregar);
        panelBotones.add(btnListar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);

        // Añadir el panel de botones al JFrame
        add(panelBotones, BorderLayout.CENTER);

        // Tabla para mostrar los libros recuperados de la base de datos
        tableModel = new DefaultTableModel(new String[]{"ID", "Título", "Autor", "Año"}, 0); // Definir columnas
        table = new JTable(tableModel); // Crear tabla con el modelo
        JScrollPane tableScroll = new JScrollPane(table); // Añadir scroll a la tabla

        // Añadir la tabla con scroll en la parte inferior del JFrame
        add(tableScroll, BorderLayout.SOUTH);

        // Intentar conectar con la base de datos al inicializar la vista
        try {
            bookDAO = new BookDAO(); // Crear instancia del DAO
        } catch (SQLException e) {
            // Mostrar error si falla la conexión
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Establecer la fuente para mejorar la apariencia
        Font font = new Font("Arial", Font.PLAIN, 14); // Definir fuente
        lblId.setFont(font);
        lblTitulo.setFont(font);
        lblAutor.setFont(font);
        lblAnio.setFont(font);
        txtId.setFont(font);
        txtTitulo.setFont(font);
        txtAutor.setFont(font);
        txtAnio.setFont(font);
        btnAgregar.setFont(font);
        btnListar.setFont(font);
        btnActualizar.setFont(font);
        btnEliminar.setFont(font);
        table.setFont(font);
        table.setRowHeight(24); // Ajustar la altura de las filas de la tabla

        // Agregar listener al botón "Agregar Libro"
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarLibro(); // Llamar al método agregarLibro cuando se haga clic
            }
        });

        // Agregar listener al botón "Listar Libros"
        btnListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarLibros(); // Llamar al método listarLibros cuando se haga clic
            }
        });

        // Agregar listener al botón "Actualizar Libro"
        btnActualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarLibro(); // Llamar al método actualizarLibro cuando se haga clic
            }
        });

        // Agregar listener al botón "Eliminar Libro"
        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarLibro(); // Llamar al método eliminarLibro cuando se haga clic
            }
        });
    }

    // Método para agregar un libro a la base de datos
    private void agregarLibro() {
        String titulo = txtTitulo.getText(); // Obtener el título del campo de texto
        String autor = txtAutor.getText(); // Obtener el autor del campo de texto
        int anioPublicacion;

        try {
            // Convertir el año a entero y agregar el libro
            anioPublicacion = Integer.parseInt(txtAnio.getText());
            Book book = new Book(titulo, autor, anioPublicacion); // Crear objeto Book
            bookDAO.insertBook(book); // Insertar libro en la base de datos
            JOptionPane.showMessageDialog(null, "Libro agregado exitosamente."); // Mostrar mensaje de éxito
            limpiarCampos(); // Limpiar los campos de texto
            listarLibros(); // Actualizar la tabla de libros
        } catch (SQLException e) {
            // Mostrar mensaje de error si ocurre un problema al agregar
            JOptionPane.showMessageDialog(null, "Error al agregar libro", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            // Mostrar error si el año no es un número válido
            JOptionPane.showMessageDialog(null, "Año de publicación inválido", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método para listar libros en la tabla
    private void listarLibros() {
        try {
            // Obtener todos los libros desde la base de datos
            List<Book> libros = bookDAO.getBooks();
            tableModel.setRowCount(0); // Limpiar la tabla antes de agregar nuevos datos

            // Agregar cada libro a la tabla
            for (Book libro : libros) {
                tableModel.addRow(new Object[]{libro.getId(), libro.getTitulo(), libro.getAutor(), libro.getAnioPublicacion()});
            }
        } catch (SQLException e) {
            // Mostrar mensaje de error si ocurre un problema al listar libros
            JOptionPane.showMessageDialog(null, "Error al listar libros", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método para actualizar un libro
    private void actualizarLibro() {
        int id;
        String nuevoTitulo = txtTitulo.getText(); // Obtener el nuevo título desde el campo de texto

        try {
            id = Integer.parseInt(txtId.getText()); // Obtener el ID del campo de texto
            bookDAO.updateBook(id, nuevoTitulo); // Actualizar el libro en la base de datos
            JOptionPane.showMessageDialog(null, "Libro actualizado exitosamente."); // Mostrar mensaje de éxito
            limpiarCampos(); // Limpiar los campos de texto
            listarLibros(); // Actualizar la tabla de libros
        } catch (SQLException e) {
            // Mostrar mensaje de error si ocurre un problema al actualizar
            JOptionPane.showMessageDialog(null, "Error al actualizar libro", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            // Mostrar error si el ID no es válido
            JOptionPane.showMessageDialog(null, "ID inválido", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método para eliminar un libro
    private void eliminarLibro() {
        int id;

        try {
            id = Integer.parseInt(txtId.getText()); // Obtener el ID del campo de texto
            bookDAO.deleteBook(id); // Eliminar el libro de la base de datos
            JOptionPane.showMessageDialog(null, "Libro eliminado exitosamente."); // Mostrar mensaje de éxito
            limpiarCampos(); // Limpiar los campos de texto
            listarLibros(); // Actualizar la tabla de libros
        } catch (SQLException e) {
            // Mostrar mensaje de error si ocurre un problema al eliminar
            JOptionPane.showMessageDialog(null, "Error al eliminar libro", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            // Mostrar error si el ID no es válido
            JOptionPane.showMessageDialog(null, "ID inválido", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método para limpiar los campos de texto
    private void limpiarCampos() {
        txtId.setText("");
        txtTitulo.setText("");
        txtAutor.setText("");
        txtAnio.setText("");
    }

    // Método principal para ejecutar la aplicación
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new BookView().setVisible(true); // Crear la ventana y hacerla visible
            }
        });
    }
}
