package com.example.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.example.model.Book;
import com.example.util.DatabaseConnection;

public class BookDAO {

    private Connection connection;

    public BookDAO() throws SQLException {
        this.connection = DatabaseConnection.getConnection();
    }
    public List<Book> getBooks() throws SQLException {
        List<Book> libros = new ArrayList<>();
        String query = "SELECT * FROM libros";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);

        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String titulo = resultSet.getString("titulo");
            String autor = resultSet.getString("autor");
            int anioPublicacion = resultSet.getInt("anio_publicacion");

            Book libro = new Book(id, titulo, autor, anioPublicacion);
            libros.add(libro);
        }
        return libros;
    }
    // Create (Insert)
    public void insertBook(Book book) throws SQLException {
        String query = "SELECT * FROM libros";
        Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        ResultSet resultSet = statement.executeQuery(query);

        resultSet.moveToInsertRow();
        resultSet.updateString("titulo", book.getTitulo());
        resultSet.updateString("autor", book.getAutor());
        resultSet.updateInt("anio_publicacion", book.getAnioPublicacion());
        resultSet.insertRow();
    }

    // Read (Select)
    public void selectBooks() throws SQLException {
        String query = "SELECT * FROM libros";
        Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        ResultSet resultSet = statement.executeQuery(query);

        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String titulo = resultSet.getString("titulo");
            String autor = resultSet.getString("autor");
            int anioPublicacion = resultSet.getInt("anio_publicacion");

            System.out.println("ID: " + id + ", Titulo: " + titulo + ", Autor: " + autor + ", Año de Publicación: " + anioPublicacion);
        }
    }

    // Update
    public void updateBook(int id, String newTitulo) throws SQLException {
        String query = "SELECT * FROM libros WHERE id = " + id;
        Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        ResultSet resultSet = statement.executeQuery(query);

        if (resultSet.next()) {
            resultSet.updateString("titulo", newTitulo);
            resultSet.updateRow();
        }
    }

    // Delete
    public void deleteBook(int id) throws SQLException {
        String query = "SELECT * FROM libros WHERE id = " + id;
        Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        ResultSet resultSet = statement.executeQuery(query);

        if (resultSet.next()) {
            resultSet.deleteRow();
        }
    }
}
